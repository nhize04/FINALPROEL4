﻿using Microsoft.AspNetCore.Mvc;

namespace Sinoy_UserManagement.Controllers
{
    public class AccountController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
