using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Sinoy_UserManagement.Context;
using Sinoy_UserManagement.Models;
using Microsoft.AspNetCore.Http; // Required for Session
using System.Linq; // Required for Count()

namespace Sinoy_UserManagement.Controllers
{
    public class HomeController : Controller
    {
        private readonly MyDBContext _context;

        public HomeController(MyDBContext context)
        {
            _context = context;
        }

        // GET: Home
        public async Task<IActionResult> Index()
        {
            var people = await _context.People.Include(p => p.User).ToListAsync();
            ViewBag.UserRole = HttpContext.Session.GetString("UserRole"); // Get user role from session
            TempData["UserRole"] = HttpContext.Session.GetString("UserRole");
            return View(people);
        }

        // GET: Home/Create
        public IActionResult Create()
        {
            if (HttpContext.Session.GetString("UserRole") != "Admin")
            {
                return RedirectToAction("Index"); // Or return an error page.
            }
            return View();
        }

        // POST: Home/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Firstname,Lastname,Email,User")] Person person)
        {
            if (ModelState.IsValid)
            {
                // Check for existing admins
                int adminCount = await _context.Users.CountAsync(u => u.Role == "Admin");
                if (person.User.Role == "Admin" && adminCount > 0)
                {
                    ViewBag.ErrorMessage = "Only one Admin user is allowed.";
                    return View(person); // Return to the Create view with the error
                }

                person.DateCreated = DateTime.Now;

                _context.Users.Add(person.User);
                await _context.SaveChangesAsync();
                    
                person.UserId = person.User.Id;

                _context.People.Add(person);
                await _context.SaveChangesAsync();

                return RedirectToAction(nameof(Index));
            }
            return View(person);
        }

        // GET: Home/Update/5
        public async Task<IActionResult> Update(int? id)
        {
            if (HttpContext.Session.GetString("UserRole") != "Admin")
            {
                return RedirectToAction("Index"); // Or return an error page.
            }
            if (id == null)
            {
                return NotFound();
            }

            var person = await _context.People
                .Include(p => p.User)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (person == null)
            {
                return NotFound();
            }

            return View(person);
        }

        // POST: Home/Update/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Update(int id, Person person)
        {
            if (id != person.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                // Get the current person and user from the database
                var existingPerson = await _context.People.FindAsync(person.Id);
                var existingUser = await _context.Users.FindAsync(person.User.Id);

                if (existingPerson == null || existingUser == null)
                {
                    return NotFound();
                }

                // Check for existing admins, excluding the one being updated
                int adminCount = await _context.Users.CountAsync(u => u.Role == "Admin" && u.Id != person.User.Id);
                if (person.User.Role == "Admin" && adminCount > 0)
                {
                    ViewBag.ErrorMessage = "Only one Admin user is allowed.";
                    return View(person); // Return to the Update view with the error
                }

                // Update person properties
                existingPerson.Firstname = person.Firstname;
                existingPerson.Lastname = person.Lastname;
                existingPerson.Email = person.Email;
                existingPerson.DateUpdated = DateTime.Now;

                // Update user properties
                existingUser.Username = person.User.Username;
                existingUser.Password = person.User.Password; //  Ideally, hash this!
                existingUser.Role = person.User.Role; // Update the role here

                // Save changes
                await _context.SaveChangesAsync();

                return RedirectToAction(nameof(Index));
            }
            return View(person);
        }

        // GET: Home/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (HttpContext.Session.GetString("UserRole") != "Admin")
            {
                return RedirectToAction("Index"); // Or return an error page.
            }
            if (id == null)
            {
                return NotFound();
            }

            var person = await _context.People
                .Include(p => p.User)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (person == null)
            {
                return NotFound();
            }

            return View(person);
        }

        // POST: Home/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var person = await _context.People
                .Include(p => p.User)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (person == null)
            {
                return NotFound();
            }

            // Check if the user to be deleted is the last admin.  Prevent deleting the last admin.
            if (HttpContext.Session.GetString("UserRole") == "Admin" && person.User.Role == "Admin" && _context.Users.Count(u => u.Role == "Admin") == 1)
            {
                ViewBag.ErrorMessage = "Cannot delete the last Admin user.";
                return View(person);
            }

            // First remove the Person
            _context.People.Remove(person);

            // Then remove the associated User
            if (person.User != null)
            {
                _context.Users.Remove(person.User);
            }

            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }

        public IActionResult LoginPage()
        {
            return View();
        }

        // POST: /Account/Login  --> Changed route name.  Much cleaner.
        [HttpPost]
        public IActionResult Login(string username, string password, bool rememberMe)
        {
            if (string.IsNullOrEmpty(username))
            {
                ViewBag.ErrorMessage = "Username is required";
                return View("LoginPage"); // Return to the login page with the error
            }
            if (string.IsNullOrEmpty(password))
            {
                ViewBag.ErrorMessage = "Password is required";
                return View("LoginPage");
            }


            var user = _context.Users.FirstOrDefault(u => u.Username == username && u.Password == password); //  USE HASHED PASSWORDS


            if (user != null)
            {
                // Authentication successful
                HttpContext.Session.SetString("UserRole", user.Role); // Store role in session.
                // Use TempData to pass the role to the Index action
                TempData["UserRole"] = user.Role;
                return RedirectToAction("Index", "Home");
            }
            else
            {
                ViewBag.ErrorMessage = "Invalid username or password";
                return View("LoginPage"); // Stay on login page, show error.
            }

        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("LoginPage", "Home"); // Explicitly go to LoginPage
        }

        private bool PersonExists(int id)
        {
            return _context.People.Any(e => e.Id == id);
        }
    }
}
