using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Navaluna_UserManagement.Views.Home
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
