using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Navaluna_UserManagement.Views.Home
{
    public class _ViewImportsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
